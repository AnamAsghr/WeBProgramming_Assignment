<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Registration Form | Anam Asghar </title>
    <link rel="stylesheet" href="a.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
  <form method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
  <div class="title">Hello</div>
  <p>This is | <a  style="color:dodgerblue"> Anam Asghar@2K18_CSM_19 </a> </p>
    <div class="content">
    <div class="user-details">
    
        <h1> <a  style="color:Brown"> Work Detail </a> </h1>
        <ol>
            <li>Like and Dislike</li>
            <li>Add Post.</li>
            <ul>You can add new post to Blog Host</ul>
            <li>Delete Post.</li>
            <ul>You can delete existing post to Blog Host</ul>
            <li>Read Posts.</li>
            <li>Registration.</li>
            <ul> Create new user</ul>
            <li>Todo.</li>
            <div>
              <div>
            <div class="button">
              <a href="http://localhost/blog-host/home.php">
        
					  <input type="button" value="Go to Home Page" ></a> 
        </div>
        </form>
      </body>
</html>